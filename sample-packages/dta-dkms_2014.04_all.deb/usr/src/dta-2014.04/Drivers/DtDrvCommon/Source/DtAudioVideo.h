//#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#* DtAudioVideo.h *#*#*#*#*#*#*#*#*#*# (C) 2014 DekTec
//
// Driver common - Audio Video - audio/video types/functions
//

#ifndef __DT_AUDIO_VIDEO_H
#define __DT_AUDIO_VIDEO_H

//-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.- Public functions -.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-
DtStatus  DtAvGetFrameProps(Int VidStd, DtAvFrameProps*  pProps);

#endif // __DT_AUDIO_VIDEO_H